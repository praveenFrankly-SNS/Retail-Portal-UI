
class InvalidInputException(Exception):
    pass
